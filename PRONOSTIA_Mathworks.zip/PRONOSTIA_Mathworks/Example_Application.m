%%
% To be able to undrestand these codes, you have to read this work
% carefuly: check the article referenced with the same link in the description
% provided in "File Exchange" Mathworks
% 
% Before runining this program, You have to make sure that
% "Example_Preparation.m" is executed and "Prepared-data.mat" file is
% generated.
% This program is an example of Remaining useful Life (RUL) prediction with
% a deep learning algorithm (i.e. LSTM) applied on PRONOSTIA-FEMTO dataset.
% 
clear all
clc
%% Load prepared data
%%
% 
% This file "Prepared_data.mat" is automatically generated from "Example_Preparation.m"
% 
load('Prepared_data.mat');
%% Training and testing process
addpath('codes')
% xtr =training inputs
% xts =testing inputs
% ytr =training targets
% yts =testing targets
[network]= LSTM_TB(xtr,ytr,xts,yts)% To edit LSTM hyperparameters you have to go to "LSTM_TB.m"
%% Plot score distribution results
figure (1)
plot(network.Percentage_error_vector,network.Score_vector,'.'...
    ,network.Mean_Percentage_Error,network.Mean_Score,'d','MarkerSize',12);
legend('Score distribution','Mean values');
xlabel ('Percentage error');
ylabel  ('Score value');
% add txt
x=double(network.Mean_Percentage_Error);
y=double(network.Mean_Score);
text(x,y,['(Error,Score)=' '(' num2str(x) ',' num2str(y) ')']);
text(-80,0.8,'Late prediction')
text(+40,0.8,'Early prediction')
xlim([-100 100]);
%%
% 
%  The proposed score function for the PRONOSTIA dataset makes it possible 
%  to determine how much the model accurate is. In the meantime, The percentage error allows
%  whether the prediction is an early or late prediction "for maintenance planning reasons"
%  For example:
%  1) early prediction may consume maintenace resources.
%  2) late prediction may cause damage to the system. 
% 
%% ploting curve fitting results
figure(2)
%
subplot(3,4,1)
plot(yts{1});
hold on
plot(network.yts_hat{1});
hold off
title('Bearing1_3','Interpreter','none')
legend ('Desired RUL','Predicted RUL');
xlabel ('Time(s)*10^1');
ylabel ('RUL');
%
subplot(3,4,2)
plot(yts{2});
hold on
plot(network.yts_hat{2});
hold off
title('Bearing1_4','Interpreter','none')
legend ('Desired RUL','Predicted RUL');
xlabel ('Time(s)*10^1');
ylabel ('RUL');
%
subplot(3,4,3)
plot(yts{3});
hold on
plot(network.yts_hat{3});
hold off
title('Bearing1_5','Interpreter','none')
legend ('Desired RUL','Predicted RUL');
xlabel ('Time(s)*10^1');
ylabel ('RUL');
%
subplot(3,4,4)
plot(yts{4});
hold on
plot(network.yts_hat{4});
hold off
title('Bearing1_6','Interpreter','none')
legend ('Desired RUL','Predicted RUL');
xlabel ('Time(s)*10^1');
ylabel ('RUL');
%
subplot(3,4,5)
plot(yts{5});
hold on
plot(network.yts_hat{5});
hold off
title('Bearing1_7','Interpreter','none')
legend ('Desired RUL','Predicted RUL');
xlabel ('Time(s)*10^1');
ylabel ('RUL');
%
subplot(3,4,6)
plot(yts{6});
hold on
plot(network.yts_hat{6});
hold off
title('Bearing2_3','Interpreter','none')
legend ('Desired RUL','Predicted RUL');
xlabel ('Time(s)*10^1');
ylabel ('RUL');
%
subplot(3,4,7)
plot(yts{7});
hold on
plot(network.yts_hat{7});
hold off
title('Bearing2_4','Interpreter','none')
legend ('Desired RUL','Predicted RUL');
xlabel ('Time(s)*10^1');
ylabel ('RUL');
%
subplot(3,4,8)
plot(yts{8});
hold on
plot(network.yts_hat{8});
hold off
title('Bearing2_5','Interpreter','none')
legend ('Desired RUL','Predicted RUL');
xlabel ('Time(s)*10^1');
ylabel ('RUL');
%
subplot(3,4,9)
plot(yts{9});
hold on
plot(network.yts_hat{9});
hold off
title('Bearing2_6','Interpreter','none')
legend ('Desired RUL','Predicted RUL');
xlabel ('Time(s)*10^1');
ylabel ('RUL');
%
subplot(3,4,10)
plot(yts{10});
hold on
plot(network.yts_hat{10});
hold off
title('Bearing2_7','Interpreter','none')
legend ('Desired RUL','Predicted RUL');
xlabel ('Time(s)*10^1');
ylabel ('RUL');
%
subplot(3,4,11)
plot(yts{11});
hold on
plot(network.yts_hat{11});
hold off
title('Bearing3_1','Interpreter','none')
legend ('Desired RUL','Predicted RUL');
xlabel ('Time(s)*10^1');
ylabel ('RUL');
