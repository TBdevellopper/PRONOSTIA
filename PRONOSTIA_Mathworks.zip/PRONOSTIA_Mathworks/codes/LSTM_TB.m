function [network]= LSTM_TB(XTrain,YTrain,XTest,YTest)
% Build prediction model with LSTM
numResponses = 1;
featureDimension = 1;
numHiddenUnits = 10;
layers = [ ...
    sequenceInputLayer(featureDimension)
    lstmLayer(numHiddenUnits,'OutputMode','sequence')
    fullyConnectedLayer(numResponses)
    regressionLayer];
maxEpochs = 400;
miniBatchSize = 700;
options = trainingOptions('sgdm', ...
    'MaxEpochs',maxEpochs, ...
    'MiniBatchSize',miniBatchSize, ...
    'InitialLearnRate',0.01, ...
    'GradientThreshold',1, ...
    'Shuffle','never', ...
    'L2Regularization',0.01,...
    'ExecutionEnvironment','cpu',...
    'Plots','training-progress',...
    'Verbose',0);
tic;
[net,info] = trainNetwork(XTrain,YTrain,layers,options);
Y_hat = predict(net,XTrain,'MiniBatchSize',miniBatchSize);
Tr_Time=toc;
for i=1:numel(YTrain)
    er(i)=sqrt(mse(Y_hat{i}-YTrain{i}));
end
trainingAccuracy=mean(er);
tic;
Yts_hat = predict(net,XTest,'MiniBatchSize',miniBatchSize);

Ts_Time=toc;
Score_vector=[];
Percentage_error_vector=[];
for i=1:numel(YTest)
    er(i)=sqrt(mse(Yts_hat{i}-YTest{i}));
    [R]=SCORE_PRONOSTIA_FEMTO(Yts_hat{i},YTest{i});
    temp_Mean_Score(i)=R.Score;% 
    Score_vector=[Score_vector R.s];
    Percentage_error_vector=[Percentage_error_vector R.er];
end
Mean_Score=mean(temp_Mean_Score);
Mean_Percentage_Error=mean(Percentage_error_vector);
testingAccuracy=mean(er);

  



  network.Tr_Time=Tr_Time;% training time
  network.Ts_Time=Ts_Time;% testing time
  network.Tr_rmse=trainingAccuracy;% training RMSE
  network.Ts_rmse=testingAccuracy; % testing RMSE
  network.y_hat=Y_hat;% estimated training targets
  network.yts_hat=Yts_hat;% estimated testing targets
  network.net=net;% trained LSTM
  network.Mean_Score=Mean_Score;% Mean Score value
  network.Score_vector=Score_vector;% Mean Score value
  network.Percentage_error_vector=Percentage_error_vector;% Mean Score value
  network.Mean_Percentage_Error=Mean_Percentage_Error;% Mean_Percentage_Error
  
  


end