function [y_temp]=exp_deg(TM,b)
% Designe of an expenetial degradation function
% check the article referenced with the same link in the description
% provided in "File Exchange" Mathworks
% F(X)=A-exp(-mu*X);
%
a=(-log(-1+exp(b))+b)/TM(end);
d=2-exp(b);
y_temp=flip((((2-d)-exp(-a*TM+b))));
%
end