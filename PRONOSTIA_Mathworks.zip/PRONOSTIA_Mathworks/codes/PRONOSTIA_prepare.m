function [info]=PRONOSTIA_prepare(which_Bearing)
% Preprocessing of data, 
% Check this paper: 
%% 1) Load csv files names characteristics of the user-specified bearing
l=dir([which_Bearing '//*.csv']);
%%
raw_signal=[];% initialize raw signal vector
for i=1:size(l,1)  
 filename=l(i).name;% load each files names one-by-one 
 if filename(1)=='a'% Take vibration signals only whoes files names started with latter "a" (other files represents temprature signals)
 M = load([which_Bearing '//' filename]); % load data of each file
 M=M(:,5);          % select information from a single acceleremer.
 raw_signal=[raw_signal; M]; % store raw vibration signals
 pre_signal(i,:)=std(M,0,1); % extract time domain features (i.e. standard deviation).
 else
 break
 end
 
end
%% 2) Determining total time of the test (each frame is recoreded in 10 seconds).
Total_Time=(i-1)*10; 
%% 3) Data labeling
% The RUL in this case is defined as an exponential degrdation function.
% read this paper to discover how and why: check the article referenced with the same link in the description
% provided in "File Exchange" Mathworks.
[RUL]=exp_deg(1:length(pre_signal),0.0001);% check "codes\exp_deg.m" for more information
%% 4) Data normalization
pre_signal=scaledata(pre_signal,0,1);
%% 5) Time vectors
clearvars -except which_Bearing raw_signal pre_signal RUL Total_Time 
% Prepare time vector for raw signal.
Time_raw=scaledata([1:length(raw_signal)],0,Total_Time);
% Prepare time vector for prepared signal.
Time_pre=scaledata([1:length(pre_signal)],0,Total_Time);% prepare time vector for row signal.
%% 6)save parepared data
info.which_Bearing=which_Bearing;
info.raw_signal=raw_signal;
info.pre_signal=pre_signal;
info.RUL=RUL;
info.Time_raw=Time_raw;
info.Time_pre=Time_pre;
end
 