function [R]=SCORE_PRONOSTIA_FEMTO(Y_hat,Y)
% Score function, check the article referenced with the same link in the description
% provided in "File Exchange" Mathworks;
E=100*((Y-Y_hat)./Y);
%% fined early and late predictions
I1=find(E<=0);
I2=find(E>0);
%% penalization
s(I1)=exp(-log(0.5)*(E(I1)/5));
s(I2)=exp(+log(0.5)*(E(I2)/20));
%% Mean value
Score=mean(s);
%% Save results
R.Score=Score;% Mean of the Score
R.er=E;       % percentage error vector
R.s=s;        % Score vector
%R.p=Precision;
end